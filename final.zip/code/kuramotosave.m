function [r] = kuramotosave(K ,display)
%Kuramoto
%N = Number of Oscillators
Nx = 10;
Ny = 10;
N = Nx*Ny;
degree = [];
%Generating Initial Random Frequencies
%Generated from normal uniform distribution on interval [0,1]
%For specific interval [a,b] = a + (b-a) .* rand(1, N)
omega = randn(N, 1);   
    
%Coupling Constant K
S = sparse(Nx*Ny, Nx*Ny);
 
%Initial Random Graph
for k = 1:Nx*Ny
    for l = 1:Nx*Ny
    p = rand(k, l);
    if p(k,l) > 0.99
        S(k, l) = 1;
    end
    end
end

%Adj Updating
for k = 1:Nx*Ny
    for l = 1:Nx*Ny
        Ki(k) = sum(S(k, :));
        Ko(k) = sum(S(:, k));
        Q = randi(100, 10, 10);
        if sum(S(Q(k), :)) > 1
        S(Q(k), l) = 1;
        M = find(S(Q(k), :) > 1);
        S(M, l) = 1;
        elseif sum(S(Q(k), :) == 0)
            S(Q(k), Q(l)) = 1;
        end
        degree(k) = sum(S(k, :));
    end
end

S = S*K;

%Time
tStep = 0.1;
t = (0:tStep:50);

%Random Initial Phases on interval [0, 2pi]
thetamin = -pi;
thetamax = pi;
theta = zeros(N, 1);
%for k = 1:N;
%    theta(k) = thetamin + (thetamax - thetamin) * rand;
    theta0 = thetamin + (thetamax - thetamin) * rand(N,1);
    theta0 = mod(theta0, 2*pi);
%end



%Numerical Integration 
[t, theta] = ode45(@ode, t, theta0);
r = zeros(1, size(t, 1));
for l = 1:(size(t, 1))
z = theta(l,:);
r(l) = abs(sum (exp(i*z))./N); %Coherence - Order Parameter

end
 if display == true
    figure
    subplot(1, 2, 1)
    plot(t, theta)
    xlabel('time')
    ylabel('theta')
    subplot(1, 2, 2)
    plot(t, r)
 end

 

%Governing Equation
function dtheta = ode(t,theta);
    dtheta = zeros(N,1);
    noise = randn(N, 1);
    for k = 1:N
        dtheta(k) = omega(k) + noise(k) + 1/N * sum(S(k, :) * sin(theta - theta(k) - 1.1));
        %dtheta(k) = omega(k) + K/N * sum(sin(theta - theta(k)));
            %Sync = find(dtheta(k) - dtheta < pi/2);
            %S(k, Sync) = S(k, Sync) + 0.75;
           
     end
end
    %dtheta = omega + (K/N)*dtheta
end



