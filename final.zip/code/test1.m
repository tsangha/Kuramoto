N = 25
S = zeros(N, N)
%Initial Random Graph
for k = 1:N
    for l = 1:N
    p = rand(k, l);
    if p(k,l) > 0.8
        S(k, l) = 1;
    end
    end
end

%Adj Updating
for k = 1:N
    for l = 1:N
        Ki(k) = sum(S(k, :));
        Ko(k) = sum(S(:, k));
        Q = randi(N, N, N);
        if sum(S(Q(k), :)) > 1
        S(Q(k), l) = 1;
        M = find(S(Q(k), :) > 1);
        S(M, l) = 1;
        elseif sum(S(Q(k), :) == 0)
            S(Q(k), Q(l)) = 1;
        end
    end
end
S
view(biograph(S))