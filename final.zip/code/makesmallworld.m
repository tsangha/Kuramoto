function A = makesmallworld(N, pw)
%function takes N = number of nodes, and pw = probability of rewiring 
% CREATE RING LATTICE OF SIZE N
A = zeros(N, N);
for i = 1:N
        if i-1 < 1
            A(i, N) = 1;
            A(N, i) = 1;
        elseif i+1 > N
            continue
        else
        A(i, i+1) = 1;
        A(i+1, i) = 1;
        A(i, i-1) = 1;
        A(i-1, i) = 1;
end
end

%REWIRE NODES WITH PROBABILITY pw, kL = # of edges in initial ring lattice
%per node

kL = 4;

for i = 1: N
    if pw > rand
        rewireto = randi(N, 1, 1);
        if rewireto ~= i & A(i, rewireto) == 0
            cxns = find(A(i, :));
            disconnect = cxns(randi(length(cxns), 1, 1));
            A(i, disconnect) = 0;
            A(i, rewireto) = 1;
        end
    end
end

            
            