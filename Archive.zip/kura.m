function [r] = kura()
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
N = 25;
S = sparse(N, N);
K = 3;
omega = randn(N, 1);
noise = randn(N, 1);

tstep = 0.1;
t = (0:tstep:15);

thetamin = -pi;
thetamax = pi;
theta = zeros(N, 1);
theta0 = thetamin + (thetamax - thetamin) * rand(N, 1);
theta0 = mod(theta0, 2*pi);

[r, theta] = ode45(@ode, t, theta0);
r = zeros(1, 151);
for l = 1:151;
    z = theta(l, :);
    r(l) = abs(sum(exp(i*z))./N);
end



figure 
subplot(1, 2, 1)
plot(t, theta)
subplot(1,2,2)
plot(t, r)

    function dtheta = ode(t, theta);
        dtheta = zeros(N, 1);
        
       for k = 1:N
            dtheta(k) = omega(k) + K/N * sum(sin(theta - theta(k)));
        end
    end
end

