function [r] = kura(K)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
% 
%   a = [0 1 1 0 0 ; 1 0 1 0 1; 1 1 0 1 0; 0 0 1 0 1; 0 1 0 1 0];
%  a1 = kron(a, a);
%  A = kron(a1, a1);

 N = 100
 A = sparse(N, N)
for i = 1:N
    for j = 1:N
        p = rand;
        if p > 0.7
            A(i, j) = 1;
        end
    end
end

%A = K.*makesmallworld(N, 0.3);
omega = randn(N, 1);
noise = randn(N, 1);

%A = K.*A;
tstep = 0.1;
t = (0:tstep:15);
thetamin = -pi;
thetamax = pi;
theta = zeros(N, 1);
theta0 = thetamin + (thetamax - thetamin) * rand(N, 1);
theta0 = mod(theta0, 2*pi);

[r, theta] = ode45(@ode, t, theta0);
r = zeros(1, 151);
for l = 1:151;
    z = theta(l, :);
    r(l) = abs(sum(exp(i*z))./N);
end




figure 
subplot(1, 2, 1)
plot(t, theta)
xlabel('Time')
ylabel('Phase')
subplot(1,2,2)
plot(t, r)
xlabel('Time')
ylabel('Synchrony')

    function dtheta = ode(t, theta);
        dtheta = zeros(N, 1);
        
       for k = 1:N
            dtheta(k) = omega(k)+ 1/N *sum(A(k, :))* sum(sin(theta - theta(k)));
        end
    end
end

