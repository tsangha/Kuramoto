function [r] = kvary()
Kappa = [0:0.25:10];
r = zeros(size(Kappa));
K = 1

for l = 1:length(Kappa)
    k = Kappa(l);
    ts = kuramotosave(k * K, true);
    r(l) = mean(ts);
end

plot(Kappa,r)